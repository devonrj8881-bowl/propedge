# PropEdge Session Notes — 2026-04-15

## ✅ What Was Done This Session

### PropIQ v2 — Scoring Engine Overhaul
All changes applied to: `propedge-deploy/index.html`
Deployed live to: https://propedgemasters.netlify.app
Deploy ID: `69df2cbec8fee07cb8943573` (published 06:14 UTC)

### Fixes Applied

| Fix | Description |
|-----|-------------|
| **A — Graduated Hit Rate** | +8/+5/+2/−4 based on L10+L5 strength (was binary +5) |
| **B — Signed Streak** | Miss streaks now penalize score (−1 to −4 by sport) |
| **C — Sport Hit Rate Weights** | NBA: L5=40%, L10=25%. MLB: season=35%, L20=35%. NHL/NFL unchanged |
| **D — Sharp Money** | `rescoreSharpMoney()` fires after line movements load — boosts +2/+3/+5 by move type |
| **E — Devig** | Implied prob × 0.952 to strip sportsbook vig before edge calc |
| **F — Ultimate Bar** | NBA/NHL/NFL: pfRating≥84, L10≥75%, L5≥70%, L20≥65% (was pfR≥82, L10≥70%) |
| **G — Matchup Guard** | Matchup bonus only fires if L20≥50% AND seasonPct≥48% |
| **Thresholds** | prime→83, strong→71, solid→60 (calibrated for new scoring range) |

### Timing Bug Fixed
Sharp money was previously read inside `parseCSV()` where `state.lineMovements` is always empty.
Now: `rescoreSharpMoney()` is a separate function called after `loadLineMovement()` completes,
which iterates `state.props` and applies boost + re-calculates tier live.

---

## 🕐 Next Check — 11:30am

When scraper runs at 11:30am, open https://propedgemasters.netlify.app and verify:
- Props load normally ✅
- Scores look reasonable (not all spiked to 90+ or all dropped to 50) 
- Ultimate tier is harder to hit (should be fewer players there)
- Cold players / miss streaks get lower scores than before
- If sharp money data is in Line_History sheet — check console for "📈 Sharp money applied to X prop(s)"

---

## Files Changed
- `PropEdge/propedge-deploy/index.html` — live deployed version ✅
- `PropEdge/index.html` — root copy also patched (kept in sync)

## Files NOT Changed
- Layout, tabs, FanDuel links, Parlay tab, Strategy tab — all untouched
- Google Sheet structure — no changes needed
