# 🚀 PROJECT BLUEPRINT & COWORK INSTRUCTIONS
## PropEdge — Daily Sports Prop Model

---

## 🎯 1. Mission & Context

- **Project Name:** PropEdge
- **Core Goal:** This is Devon's sports betting prop model project. PropEdge is a standalone offline single-file HTML app for daily NBA, NHL, and MLB player prop analysis.
- **User:** Devon — advanced user building practical betting tools with a strong preference for efficient, accurate, patch-based updates.
- **Primary Sportsbook:** FanDuel
- **Operating Mode:** Claude Desktop CoWork with a mounted local project folder.
- **This is my real environment:** Files in this folder are my actual local project files. Changes must be applied to the mounted folder on my computer, not to a throwaway sandbox output, demo copy, or internal prototype unless I explicitly request that.

---

## 📁 2. Mounted Folder Contract

- **Mounted Project Folder:** `[INSERT FULL LOCAL PATH HERE]`
- **Primary App File:** `PropEdge.html`
- **Project Instruction File:** `CLAUDE.md`
- **Optional Handoff File:** `SESSION_NOTES.md`
- **Optional Source Notes:** `data-notes.md`

### Required startup verification

Before making any edit, verify that you are operating inside the mounted local folder.

You must do all of the following at the start of each session:
1. Confirm the working folder path matches the mounted project folder.
2. Confirm that `PropEdge.html` and `CLAUDE.md` are visible in that folder.
3. State clearly which file you will read first.
4. If you cannot verify the mounted folder or cannot see the expected files, stop and tell me before doing anything else.

### File write rule

- All final edits must be written directly to `PropEdge.html` in the mounted folder.
- Do not create a new demo HTML file, alternate build, duplicate app, or sandbox-only output unless I explicitly ask.
- If a task requires experimentation, use a temporary scratch approach only if necessary, then apply the approved final patch back into `PropEdge.html`.
- If you are unable to write to the mounted folder, say so immediately instead of pretending the task is complete.

---

## 🛠️ 3. App Architecture & Environment

- **App Type:** Standalone offline single-file HTML app
- **File Structure Preference:** One self-contained `.html` file with inline CSS and JavaScript, no external app dependencies, no separate CSS/JS files
- **Main Tabs:** Players | Parlay | Strategy
- **Critical Layout Rule:** `Parlay` and `Strategy` tabs must remain siblings outside `#main` to avoid the blank tab bug
- **Primary Output:** One finished `PropEdge.html` file ready to open locally in a browser
- **Sports Covered:** NBA, NHL, MLB
- **Default Change Style:** Small, targeted patches to the existing app rather than full rebuilds

---

## 📋 4. Working Rules for CoWork

### 4.1 Real files, not sandbox

- Treat the mounted folder as the source of truth.
- Read from and write to the actual files in this folder on my computer.
- Do not default to internal sandbox outputs when the task is clearly a real project edit.
- If you are about to create or modify a file anywhere other than the mounted project folder, say so first.

### 4.2 Patch, don’t rewrite

- Do not rewrite the full HTML file unless I explicitly say to rebuild from scratch.
- Prefer targeted edits to the exact sections that need updating: player cards, data objects, styling tweaks, scoring logic, links, or tab behavior.
- When possible, preserve line order, comments, naming conventions, and existing formatting style.

### 4.3 Preserve structure

- Match the existing card layout, color scheme, spacing, and tab structure from prior PropEdge builds.
- Preserve the existing DOM architecture unless a structural fix is necessary.
- Never move `Parlay` or `Strategy` inside `#main`.
- Do not reorganize unrelated sections just because you see a cleaner way to structure them.

### 4.4 Scope transparency

Before making changes, tell me:
- Which file(s) you will read
- Which section(s) you expect to edit
- Whether the change is low-risk or could affect layout, scoring, or deep-link generation

If a requested change could affect layout, scoring, tab behavior, or FanDuel deep-link generation, explain intended scope first.

### 4.5 Completion transparency

When a task is complete, report:
- The file edited
- The section(s) changed
- Whether the write was applied directly to the mounted local file
- Any unconfirmed data or unresolved risk

Do not say a file is updated unless the final change was actually written to the mounted local file.

---

## 📊 5. Daily Build Inputs

For each daily PropEdge build or refresh, pull and verify when requested:

- Live schedule
- Confirmed starters and lineups where available
- Injury reports
- Current FanDuel lines for relevant props
- Recent L10 performance per player

If any line, injury, lineup, or starter data cannot be confirmed:
- Clearly flag it inside the app and in your response
- Mark it as unconfirmed
- Do not guess or silently fill missing data

Because injuries, lineups, and starting status can materially change prop value, uncertain inputs must always be labeled clearly rather than inferred. [web:33]

---

## 🧮 6. Model & Output Expectations

- **Scoring Engine:** Use calibrated tiers, L10 hit rate bars, and defensive matchup ratings
- **Player Cards:** Must show target tiers per player
- **Parlay Tab:** Must include EV calculations
- **FanDuel Integration:** Include FanDuel deep-link buttons per prop and preserve the established FanDuel-specific linking format already used in this project
- **Verification Rule:** If deep-link format, line mapping, or prop identifiers cannot be confirmed from the existing project context or verified source data, flag the issue rather than inventing a format
- **Output Destination:** Final changes must be applied directly to `PropEdge.html` in the mounted local folder

---

## ⚡ 7. Token & Context Discipline

- Read `PropEdge.html` and small reference files first before scanning unrelated files.
- Avoid re-reading the full HTML repeatedly if only one section needs patching.
- For updates, focus only on the specific sport, date, or section involved unless I ask for a full rebuild.
- Keep responses concise and practical: direct answer first, then necessary implementation notes.
- Do not paste giant HTML blocks unless I ask.
- Prefer a short diff, exact snippet, or compact summary of changed sections.

---

## 🧠 8. Memory & Session Practices

- Treat this file as the standing project contract for all PropEdge sessions.
- Reuse prior project structure and conventions whenever possible so daily builds remain consistent and token-efficient.
- Keep a short running summary of:
  - what changed today
  - what data was confirmed
  - what still needs review
- If the session becomes long, write a brief handoff summary to `SESSION_NOTES.md` instead of repeating all project context.

---

## 💬 9. Response Style

- Start with the exact answer, patch, or next action.
- Be concise by default.
- Use small diffs or targeted snippets instead of full rewrites.
- If data is missing, ask one focused question or clearly mark the data as unconfirmed.
- Assume the mounted folder is readable and writable only after verifying it at session start.
- If folder access is missing or output location is unclear, say that immediately.

---

## 🔒 10. Safety & Change Control

- Before running commands or making edits that could delete, rename, move, or bulk-rewrite files, explain what will happen and wait for approval.
- Do not modify archived files unless I explicitly ask.
- Do not rename `PropEdge.html` unless I explicitly ask.
- Do not create extra versions like `PropEdge-new.html`, `PropEdge-fixed.html`, or `PropEdge-v2.html` unless I explicitly ask for a side-by-side variant.
- Prefer reversible edits and minimal diffs.

---

## 📦 11. Folder Snapshot

```bash
PropEdge/
├── CLAUDE.md
├── PropEdge.html
├── SESSION_NOTES.md
├── data-notes.md
└── archives/
    ├── PropEdge-2026-04-04.html
    └── PropEdge-2026-04-05.html
```

---

## ✅ 12. Session Start Checklist

At the start of every CoWork session, do this in order:

1. Confirm the mounted folder path.
2. Confirm `PropEdge.html` and `CLAUDE.md` are present.
3. Read `CLAUDE.md` first for project rules.
4. Read only the minimum necessary part of `PropEdge.html`.
5. State the exact file and section you plan to edit.
6. Apply a targeted patch.
7. Confirm the final write was made to the mounted local file.

If any of those steps cannot be completed, stop and tell me exactly what is blocked.

---

## ✅ 13. Preferred Default Behavior

Unless I say otherwise:
- edit the existing `PropEdge.html`
- preserve the current layout and tab architecture
- use patch-based updates
- keep archive files untouched
- avoid sandbox-only outputs
- flag uncertainty instead of guessing