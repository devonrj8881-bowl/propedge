/**
 * PropFinder Auto-Sync Scraper v14 (FanDuel-Exclusive Architecture)
 * =================================================================
 *
 * Architectural Refactoring:
 *  - Enforces strict UI navigation state machine to isolate FanDuel-only odds.
 *  - Resolves MUI aria-hidden modal blocking via DOM sanitization (_unhideModals).
 *  - Overcomes React synthetic event swallowing utilizing hardware-coordinate clicking.
 *  - Implements dynamic CSV column mapping and anomaly ('saved' column) stripping.
 *  - Eradicates Props_History appending, preventing 10,000,000 cell limit API exhaustion.
 *  - Enforces strict -350 to +350 odds filtering to reject heavy-juice alternate lines.
 */

require('dotenv').config();
const puppeteer = require('puppeteer-core');
const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');

// -----------------------------------------------------------------------------
// Initialization and Environment Discovery
// -----------------------------------------------------------------------------

/**
 * Dynamically traverses the local file system to locate the Chrome/Chromium 
 * executable across supported macOS and Linux installation paths.
 */
function findChrome() {
    const possiblePaths =;

    for (const chromePath of possiblePaths) {
        try {
            if (fs.existsSync(chromePath)) {
                console.log(`✅ Chrome executable verified at: ${chromePath}`);
                return chromePath;
            }
        } catch (e) {
            // Suppress access exceptions and proceed with discovery
        }
    }
    console.log('⚠️ Standard paths exhausted. Delegating discovery to Puppeteer environment variables.');
    return null;
}

const CHROME_PATH = findChrome();
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const CONFIG = {
    email: process.env.PROPFINDER_EMAIL,
    password: process.env.PROPFINDER_PASSWORD,
    spreadsheetId: process.env.GOOGLE_SHEET_ID,
    leagues:,
    downloadPath: path.join(process.env.HOME, 'Downloads'),
    headless:!process.argv.includes('--visible'),
    viewport: { width: 1400, height: 900 }
};

// Application of mathematical boundaries to the raw CSV matrix
const FILTERS = {
    pfRatingMin: 55,   // Accommodates rating variance resulting from single-book isolation
    oddsMin: -350,     // Strictly reject heavy juice / alternate market lines
    oddsMax: 350       // Symmetrical positive boundary
};

function log(msg, indent = 0) {
    console.log(` ${'  '.repeat(indent)}${msg}`);
}
function logSuccess(msg, indent = 0) { log(`✅ ${msg}`, indent); }
function logWarning(msg, indent = 0) { log(`⚠️  ${msg}`, indent); }
function logError(msg, indent = 0) { log(`❌ ${msg}`, indent); }

// -----------------------------------------------------------------------------
// Google Sheets API Integration (Atomic Overwrite Model)
// -----------------------------------------------------------------------------

async function getGoogleSheetsClient() {
    const auth = new google.auth.GoogleAuth({
        keyFile: './credentials.json',
        scopes: ['https://www.googleapis.com/auth/spreadsheets']
    });
    return google.sheets({ version: 'v4', auth: await auth.getClient() });
}

/**
 * Executes a destructive overwrite of the target league tab.
 * Guarantees zero stale data persistence and strict memory management.
 */
async function writeToSheet(sheets, tabName, headers, dataRows) {
    log(`Initiating atomic synchronization for: ${tabName}`, 1);

    try {
        // Step 1: Wipe existing range to prevent ghost data
        await sheets.spreadsheets.values.clear({
            spreadsheetId: CONFIG.spreadsheetId,
            range: `${tabName}!A:Z`
        });
        log('Previous dataset successfully eradicated.', 2);
    } catch (e) {
        logWarning(`Clear operation bypassed (tab may be uninitialized): ${e.message}`, 2);
    }

    try {
        // Step 2: Inject fresh, FanDuel-exclusive dataset
        const values =;
        await sheets.spreadsheets.values.update({
            spreadsheetId: CONFIG.spreadsheetId,
            range: `${tabName}!A1`,
            valueInputOption: 'RAW',
            resource: { values }
        });
        logSuccess(`Successfully synchronized ${dataRows.length} records to ${tabName}`, 2);
        return true;
    } catch (e) {
        logError(`Synchronization failure: ${e.message}`, 2);
        return false;
    }
}

// -----------------------------------------------------------------------------
// Data Ingestion and Sanitization Modules
// -----------------------------------------------------------------------------

/**
 * State-machine CSV parser. Secures data integrity by handling embedded commas 
 * within double-quoted strings (e.g., complex prop descriptions or player names).
 */
function parseCSV(text) {
    return text.trim().split('\n').map(line => {
        const result =;
        let current = '', inQuotes = false;
        for (const char of line) {
            if (char === '"') inQuotes =!inQuotes;
            else if (char === ',' &&!inQuotes) { 
                result.push(current.trim()); 
                current = ''; 
            }
            else current += char;
        }
        result.push(current.trim());
        return result;
    });
}

/**
 * Polls the file system for the most recently modified CSV payload.
 * Restricts matches to files modified within 60 seconds to guarantee freshness.
 */
function findLatestCSV(maxAgeMs = 60000) {
    try {
        if (!fs.existsSync(CONFIG.downloadPath)) return null;
        
        const files = fs.readdirSync(CONFIG.downloadPath)
           .filter(f => f.endsWith('.csv'))
           .map(f => ({
                name: f,
                path: path.join(CONFIG.downloadPath, f),
                time: fs.statSync(path.join(CONFIG.downloadPath, f)).mtime.getTime()
            }))
           .sort((a, b) => b.time - a.time);

        if (files.length > 0 && (Date.now() - files.time) < maxAgeMs) {
            return files.path;
        }
    } catch (e) {
        logError(`File system access error: ${e.message}`);
    }
    return null;
}

/**
 * Normalizes the CSV matrix, strips anomalies, and enforces mathematical boundaries.
 */
function applyFilters(rows) {
    if (!rows |

| rows.length < 2) return { headers:, data: };

    let headers = rows;
    let data = rows.slice(1);

    // Anomaly Mitigation: Detect and slice out dynamic 'saved' bookmark column
    const savedIdx = headers.map(h => h.toLowerCase().trim()).indexOf('saved');
    if (savedIdx!== -1) {
        headers = headers.filter((_, i) => i!== savedIdx);
        data = data.map(row => row.filter((_, i) => i!== savedIdx));
        log(`Normalized schema: Stripped anomalous 'saved' column at index ${savedIdx}`, 2);
    }

    const headerLower = headers.map(h => h.toLowerCase().trim());

    // Dynamic index mapping ensures resilience against upstream schema alterations
    const cols = {
        pf: headerLower.findIndex(h => h.includes('pf') && h.includes('rating')),
        odds: headerLower.findIndex(h => h === 'odds')
    };

    const validData = data.filter(row => {
        try {
            // Enforce quality floor
            if (cols.pf >= 0) {
                const pfVal = parseFloat(row[cols.pf]);
                if (!isNaN(pfVal) && pfVal < FILTERS.pfRatingMin) return false;
            }
            
            // Enforce odds boundaries (reject alternate/heavy-juice lines)
            if (cols.odds >= 0) {
                const oddsStr = (row[cols.odds] |

| '').replace(/[',+]/g, '');
                const oddsVal = parseInt(oddsStr, 10);
                if (!isNaN(oddsVal)) {
                    if (oddsVal < FILTERS.oddsMin |

| oddsVal > FILTERS.oddsMax) return false;
                }
            }
            return true;
        } catch (e) {
            return false; // Safely discard malformed rows
        }
    });

    log(`Sanitization complete. Preserved ${validData.length} of ${data.length} records.`, 2);
    return { headers, data: validData };
}

// -----------------------------------------------------------------------------
// Browser Automation and DOM Interaction Overrides
// -----------------------------------------------------------------------------

/**
 * Defeats Material-UI accessibility tree encapsulation.
 * Eliminates aria-hidden attributes, allowing Puppeteer to map viewport coordinates.
 */
async function _unhideModals(page) {
    await page.evaluate(() => {
        document.querySelectorAll('[aria-hidden="true"]').forEach(el => {
            el.removeAttribute('aria-hidden');
        });
    });
}

/**
 * Text-based element interaction utilizing flexible substring matching.
 */
async function _clickByText(page, text, timeoutMs = 5000) {
    const startTime = Date.now();
    const searchStr = text.toLowerCase();

    while (Date.now() - startTime < timeoutMs) {
        await _unhideModals(page);
        
        const clicked = await page.evaluate((searchStr) => {
            const buttons = Array.from(document.querySelectorAll('button, [role="button"],.cursor-pointer'));
            for (const btn of buttons) {
                if (btn.textContent.toLowerCase().includes(searchStr)) {
                    btn.click();
                    return true;
                }
            }
            return false;
        }, searchStr);

        if (clicked) return true;
        await sleep(500);
    }
    return false;
}

// -----------------------------------------------------------------------------
// Core State Machine Orchestration
// -----------------------------------------------------------------------------

/**
 * Forces target application state into a FanDuel-exclusive configuration.
 * Traverses nested modals and bypasses React synthetic event swallowing.
 */
async function selectFanDuel(page) {
    log('Initiating FanDuel exclusive state machine sequence...');

    try {
        await sleep(3000);
        await _unhideModals(page);

        // Step 1: Dynamic Profile Panel Identification
        const profileOpened = await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'))
               .filter(b => {
                    const txt = b.textContent.toLowerCase();
                    return!txt.includes('tutorial') &&!txt.includes('saved');
                });
            if (buttons.length === 0) return false;
            
            // Isolate the right-most element geographically
            const rightmost = buttons.reduce((prev, curr) => {
                const pRect = prev.getBoundingClientRect();
                const cRect = curr.getBoundingClientRect();
                return (cRect.left > pRect.left)? curr : prev;
            });
            
            if (rightmost) {
                rightmost.click();
                return true;
            }
            return false;
        });

        if (!profileOpened) throw new Error("Profile navigation node obscured.");
        logSuccess('Profile panel invoked.', 1);
        await sleep(1500);

        // Step 2 & 3: Navigate Configuration Modals
        await _clickByText(page, 'settings');
        logSuccess('Settings modal invoked.', 1);
        await sleep(1500);

        await _clickByText(page, 'sportsbooks');
        logSuccess('Sportsbooks tab activated.', 1);
        await sleep(1500);

        // Step 4: Open Management Overlay
        await _clickByText(page, 'manage sportsbooks');
        logSuccess('Management overlay invoked.', 1);
        await sleep(2000);

        // Step 5: Eradicate Residual States
        await _clickByText(page, 'disable all');
        logSuccess('Global bookmaker states disabled.', 1);
        await sleep(1000);

        // Step 6: Isolate Target Bookmaker
        await _clickByText(page, 'fanduel');
        logSuccess('FanDuel bookmaker activated.', 1);
        await sleep(1000);

        // Step 7: Overlay Escape Sequence (Bypasses UI back-arrow z-index conflicts)
        await page.keyboard.press('Escape');
        logSuccess('Inner modal dismissed via physical keypress event.', 1);
        await sleep(1500);

        // Step 8: Hardware-Level Coordinate Dispatching
        // This is strictly required to defeat React synthetic event swallowing on state mutation.
        await _unhideModals(page);
        const coords = await page.evaluate(() => {
            for (const btn of document.querySelectorAll('button')) {
                if (btn.textContent.trim() === 'Save Changes') {
                    const rect = btn.getBoundingClientRect();
                    return { x: rect.left + (rect.width / 2), y: rect.top + (rect.height / 2) };
                }
            }
            return null;
        });

        if (coords) {
            log(`Save node mapped to viewport coordinates: (${Math.round(coords.x)}, ${Math.round(coords.y)})`, 1);
            await page.mouse.click(coords.x, coords.y);
            logSuccess('State configuration persisted via hardware-level click dispatch.', 1);
            
            // Crucial: Await full SPA rehydration fetching the newly filtered dataset
            await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 15000 }).catch(() => {});
            await sleep(4000);
            logSuccess('Data grid successfully re-hydrated with FanDuel-exclusive odds.', 1);
        } else {
            throw new Error("Save Changes DOM node could not be mapped to viewport.");
        }
    } catch (error) {
        logError(`State machine sequence aborted: ${error.message}`, 1);
    }
}

/**
 * Bypasses strict string matching to ensure full data slate visualization.
 */
async function selectAllGames(page) {
    log('Configuring data grid for universal slate extraction...', 1);
    
    try {
        await _unhideModals(page);
        
        // Isolate the game dropdown toggle
        const clicked = await page.evaluate(() => {
            const spans = Array.from(document.querySelectorAll('span, div, button'));
            for (const el of spans) {
                const text = el.textContent.toLowerCase().trim();
                if (text.includes('selected') |

| text.includes('game')) {
                    el.click();
                    return true;
                }
            }
            return false;
        });

        if (!clicked) {
            logWarning('Game dropdown anchor not located.', 2);
            return;
        }
        await sleep(1000);
        await _unhideModals(page);

        // Implement flexible substring matching to defeat DOM alterations
        const selectedAll = await page.evaluate(() => {
            const options = Array.from(document.querySelectorAll('li, div, span, button'));
            for (const opt of options) {
                if (opt.textContent.toLowerCase().includes('select all')) {
                    opt.click();
                    return true;
                }
            }
            return false;
        });

        if (selectedAll) {
            logSuccess('Universal slate selection confirmed.', 2);
            await page.keyboard.press('Escape'); // Dismiss dropdown
            await sleep(2000);
        } else {
            logWarning('Universal option absent; proceeding with default render.', 2);
        }
    } catch (e) {
        logWarning(`Slate selection sequence aborted: ${e.message}`, 2);
    }
}

// -----------------------------------------------------------------------------
// Pipeline Orchestration
// -----------------------------------------------------------------------------

async function processLeague(page, sheets, league) {
    log(`\n==================================================`);
    log(`Commencing extraction pipeline for: ${league}`);
    log(`==================================================`);

    try {
        // Hydrate application endpoint
        await page.goto(`https://propfinder.app/${league.toLowerCase()}`, { waitUntil: 'networkidle2' });
        await sleep(3000);
        
        // Maximize data yield
        await selectAllGames(page);

        // Establish filesystem baseline prior to extraction
        const initialCsv = findLatestCSV(10000);
        
        log('Triggering CSV export payload...', 1);
        const downloaded = await _clickByText(page, 'download', 10000) |

| await _clickByText(page, 'csv', 5000);
        
        if (!downloaded) {
            logWarning('Export anchor not detected. Pipeline halting for current league.', 1);
            return;
        }

        // Active polling mechanism for filesystem payload materialization
        let newCsv = null;
        for (let i = 0; i < 20; i++) {
            await sleep(1000);
            const checkCsv = findLatestCSV(60000);
            if (checkCsv && checkCsv!== initialCsv) {
                newCsv = checkCsv;
                break;
            }
        }

        if (!newCsv) {
            logWarning('Filesystem timeout: Payload failed to materialize.', 1);
            return;
        }

        logSuccess(`Payload extracted successfully: ${path.basename(newCsv)}`, 1);

        // Data transformation sequence
        const rawText = fs.readFileSync(newCsv, 'utf-8');
        const parsedRows = parseCSV(rawText);
        
        log(`Ingesting ${parsedRows.length} raw records into memory...`, 1);
        const { headers, data } = applyFilters(parsedRows);

        if (data.length === 0) {
            logWarning(`Dataset empty post-sanitization. Halting database update for ${league}.`, 1);
            return;
        }

        // Execute atomic push to Google Sheets
        await writeToSheet(sheets, league, headers, data);
        
    } catch (e) {
        logError(`Execution fault in ${league} pipeline: ${e.message}`, 1);
    }
}

async function run() {
    log('Initializing PropEdge Data Synchronization Daemon (v14)');
    if (!CONFIG.email ||!CONFIG.password ||!CONFIG.spreadsheetId) {
        logError('CRITICAL FAULT: Environment variables omitted. Halting initialization.');
        process.exit(1);
    }

    const sheetsClient = await getGoogleSheetsClient();
    
    const browser = await puppeteer.launch({
        executablePath: CHROME_PATH |

| undefined,
        headless: CONFIG.headless,
        defaultViewport: CONFIG.viewport,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    try {
        const page = await browser.newPage();
        
        // Override default browser security constraints to allow automated downloads
        const client = await page.target().createCDPSession();
        await client.send('Page.setDownloadBehavior', {
            behavior: 'allow',
            downloadPath: CONFIG.downloadPath
        });

        // Establish secure session
        log('Authenticating with aggregation endpoint...');
        await page.goto('https://propfinder.app/login', { waitUntil: 'networkidle2' });
        await page.type('input[type="email"]', CONFIG.email);
        await page.type('input[type="password"]', CONFIG.password);
        await page.click('button[type="submit"]');
        await page.waitForNavigation({ waitUntil: 'networkidle2' });
        logSuccess('Session established.');

        // Impose global FanDuel-exclusive state
        await selectFanDuel(page);

        // Sequentially execute extraction pipeline per configured league
        for (const league of CONFIG.leagues) {
            await processLeague(page, sheetsClient, league);
        }

    } catch (e) {
        logError(`Fatal daemon exception: ${e.message}`);
    } finally {
        await browser.close();
        log('\n==================================================');
        log('Daemon execution cycle concluded successfully.');
        log('==================================================');
    }
}

// Instantiate the execution loop
run();